<?php 
require('header.php');

?>

<section id="footer" class="wrapper">
 <div class="container">
<div class="col-sm-12 col-md-12 col-lg-12">
<h2 class="animation-box wow bounceIn animated">ABOUT MAGNA EXCHANGE</h2>
<hr>
<p>MAGNA Exchange is the best place to buy bitcoin instantly with PayPall. MAGNA Exchange is the place for you to sell your Bitcoins fast, easily and smart. You can use Paypal to trade your Bitcoins instantly and securely worldwide.

MAGNA Exchange has 24 hour support most days of the year.</p>
</div>
</div>
</section>
<br><hr>
<br>
<?php 
require('footer.php');

?>